/**
 * 
 */

/**
 * @author maden
 * Built using code from OpenDSA
 */
// 2-3 tree node implementation
public class twoThreeTree <Key extends Comparable<? super Key>, E> {
    TTNode<Key, E> root;
    public twoThreeTree () {
        root = null;
    }
    protected void insert(Key k, E e) {
        if(isEmpty()) {
            root = new TTNode<Key, E>(k, e, null, null, null, null, null);
        }
        else {
            root.inserthelp(root,  k,  e);
        }
    }
    /**
     * checks if the tree is empty
     * @return
     */
    public boolean isEmpty() {
        return root == null;
    }
    /**
     * fins the value at the given key in this tree
     * @param k the key value
     * @return null if k is not a key in this list, 
     * otherwise the element's value
     */
    protected E find(Key k) {
       return root.findhelp(root, k);
    }
    
}