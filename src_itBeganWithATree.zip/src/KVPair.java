import java.util.ArrayList;

/**
 * 
 * @author Madelyn Newcomb m1newc
 * @version 11/11/2017
 *
 */
public class KVPair <F, S> {
    private F firstHandle;
    private ArrayList<S> secondaryHandles;
    /**
     * constructor
     * @param aK the artist name's key
     * @param sK the song name's key
     */
    public KVPair (F fH, S sH) {
        firstHandle = fH;
        secondaryHandles.add(sH);
    }
    /**
     * get the artist name's key
     * @return A: artistKey
     */
    protected F getArtistHandle() {
        return firstHandle;
    }
    /**
     * get the song name's key
     * @return S: songKey
     */
    protected ArrayList<S> getSongHandles() {
        return secondaryHandles;
    }
    /**
     * deletes a secondary handle from the linked list
     * @param secondKey
     * @return
     */
    protected boolean deleteSecondaryHandle(S secondKey) {
        if(secondaryHandles == null || secondaryHandles.size() == 0) {
            return false;
            //this is an error because we shouldn't ahve any blank lists
        }
        boolean found = false;
        for(int pos = 0; pos < secondaryHandles.size(); pos++) {
            if (secondaryHandles.get(pos) == secondKey) {
                secondaryHandles.remove(pos);
                found = true;
            }
        }
        return found;
    }

}
